const Hello = () => {
  return (
    <div>
      <h1>Hello world</h1>
    </div>
  );
};

export default Hello;
