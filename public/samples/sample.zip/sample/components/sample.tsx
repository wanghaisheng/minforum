const Sample = () => {
  return (
    <div>
      <h1>Sample</h1>
    </div>
  );
};

export default Sample;
