### Sample Extension for minforum

**How to install**

**Usage**
