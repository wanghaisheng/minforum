import Sample from './components/sample';
import { addAction } from 'extensions/hooks';
import { Extension } from 'interfaces/extension';
import toast from 'react-hot-toast';
import Hello from './components/hello';

const SamplePlugin: Extension = {
  name: 'sample',
  initialize: () => {
    // Register a custom function
    addAction('doNotify', () => {
      toast.success('Payment made successfully');
    });

    // Register a sample component
    addAction('sample', () => {
      return <Sample />;
    });

    // Register a hello component
    addAction('hello', () => {
      return <Hello />;
    });
  }
};

export default SamplePlugin;
